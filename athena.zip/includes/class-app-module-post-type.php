<?php
// If this file is called directly, abort.
if (!defined('WPINC')) {
	die;
}

class Athena_App_Module_Post_Type
{
	protected static $plugin_name;
	protected static $plugin_version;
	protected static $enabled;

	public static function is_enabled() {
		return self::$enabled;
	}

	public static function init($plugin_name, $plugin_version)
	{
		self::$plugin_name    = $plugin_name;
		self::$plugin_version = $plugin_version;
		self::$enabled = Athena_Api::get_app_modules_post_type_enabled();

		if (self::$enabled) {
			add_action('init', [Athena_App_Module_Post_Type::class, 'create_posttype']);
			add_action('admin_init', [Athena_App_Module_Post_Type::class, 'add_capabilities']);
			add_filter('wp_insert_post_data', [Athena_App_Module_Post_Type::class, 'force_type_private']);
		}
	}

	static function force_type_private($post)
	{
		if ($post['post_type'] == 'app_modules' && $post['post_status'] == 'publish') {
			$post['post_status'] = 'private';
		}
		return $post;
	}

	static function add_capabilities()
	{
		$roles = array('administrator', 'editor', 'author');

		foreach ($roles as $role_name) {
			$role = get_role($role_name);
			$role->add_cap('publish_app_modules', true);
			$role->add_cap('edit_app_modules', true);
			$role->add_cap('edit_others_app_modules', true);
			$role->add_cap('read_private_app_modules', true);
			$role->add_cap('edit_app_modules', true);
			$role->add_cap('delete_app_modules', true);
			$role->add_cap('read_app_modules', true);
		}
	}

	static function create_posttype()
	{
		$supports = array(
			'title', // post title
			'editor', // post content
			'author', // post author
			'thumbnail', // featured images
			'excerpt', // post excerpt
			'custom-fields', // custom fields
			'comments', // post comments
			'revisions', // post revisions
			'post-formats', // post formats
		);
		$labels = array(
			'name' => _x('App Modules', 'plural'),
			'singular_name' => _x('Modules', 'singular'),
			'menu_name' => _x('App Modules', 'admin menu'),
			'name_admin_bar' => _x('App Modules', 'admin bar'),
			'add_new' => _x('Add App Module', 'add new'),
			'add_new_item' => __('Add New App Module'),
			'new_item' => __('New App Modules'),
			'edit_item' => __('Edit App Module'),
			'view_item' => __('View App Module'),
			'all_items' => __('All App Modules'),
			'search_items' => __('Search App Modules'),
			'not_found' => __('No App Modules found.'),
		);
		$args = array(
			'supports' => $supports,
			'labels' => $labels,
			'public' => true,
			'capability_type' => 'app_modules',
			'capabilities' => array(
				'publish_posts' => 'publish_app_modules',
				'edit_posts' => 'edit_app_modules',
				'edit_others_posts' => 'edit_others_app_modules',
				'read_private_posts' => 'read_private_app_modules',
				'edit_post' => 'edit_app_modules',
				'delete_post' => 'delete_app_modules',
				'read_post' => 'read_app_modules',
			),
			'query_var' => true,
			'rewrite' => array('slug' => 'appmodules'),
			'has_archive' => true,
			'hierarchical' => true,
			'menu_icon' => '/wp-content/plugins/athena/images/app_module_post_type.png',
			'show_in_rest' => true
		);
		register_post_type('app_modules', $args);


		// Hooking up our function to theme setup

		add_role('app_module_user', 'App module user', array(
			'read' => false,
			'edit_posts' => false,
			'delete_posts' => false,
			'read_app_modules' => true,
			'read_private_app_modules' => true
		));
	}
}

Athena_App_Module_Post_Type::init($plugin_name, $plugin_version);
