<input type='checkbox' name='athena_settings[app_modules_post_type_enabled]' <?php checked( $app_modules_post_type_enabled, 1 ); ?> value='1' />
