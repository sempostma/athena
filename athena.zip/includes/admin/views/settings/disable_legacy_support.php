<input type='checkbox' name='athena_settings[disable_legacy_support]' <?php checked( $disable_legacy_support, 1 ); ?> value='1'  />
