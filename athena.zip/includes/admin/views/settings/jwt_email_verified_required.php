<input type='checkbox' name='athena_settings[jwt_email_verified_required]' <?php checked( $jwt_email_verified_required, 1 ); ?> value='1'  />
