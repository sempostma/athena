<input type='checkbox' name='athena_settings[use_firebase_jwt]' <?php checked( $use_firebase_jwt, 1 ); ?> value='1'  />
